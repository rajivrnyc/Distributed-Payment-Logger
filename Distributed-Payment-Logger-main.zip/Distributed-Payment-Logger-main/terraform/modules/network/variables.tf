variable "project_name" { type = string }
variable "vpc_cidr" { type = string }
variable "azs" { type = list(string) }
variable "public_subnet_cidrs" { type = list(string) }
variable "private_subnet_cidrs" { type = list(string) }
variable "one_nat_gateway" { type = bool }
variable "create_interface_endpoints" {
  type    = bool
  default = true
}
variable "region" {
  type    = string
  default = null
}

data "aws_region" "current" {}

locals {
  region = coalesce(var.region, data.aws_region.current.id)
}
